$(function(){ 
//$('#main_sidebar').load('admin_menu.html');
	//$('#page-content').before($('<header class="navbar navbar-inverse navbar-fixed-top navbar-glass"></header>').load("header.html"));
	
	$('body').on('click','#main_side_menu > ul > li > a',function(e) {
	
		var $this = $(this);
		if($this.attr("href")=='#' || $this.attr("href")=='')
		{
			if($this.parent().hasClass('active')){
				$this.parent().removeClass('active');
				 $(this).parents().find('li.active').removeClass('active');
			}
			else{
				console.log('close')
				$this.parent().addClass('active');
			}
			e.preventDefault();
		}
	});
	
	// $('body').on('click','.subpages',function(e){
		// var _main_layout = $(this).data('page')+'.html'
		// $('#main_page_content').load(_main_layout);
		
		
		
	// })
	
	ReadyLogin.init();
	UiTables.init();
	FormsComponents.init(); 
	ReadyDashboard.init(); 
	
});
      
