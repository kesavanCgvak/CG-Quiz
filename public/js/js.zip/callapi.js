var at, rt, ci, cs;
ci = "100";
cs = "888";

/*==Get the List of Records from the Table==*/
function callgetlist(db, tbl, pg, rws, jobj) {
    $.ajax({
        beforeSend: function(xhr) {
            xhr.setRequestHeader("Authorization", "Bearer " + at);
        },
        url: "http://www.cgvakstage.com:5500/api/newsynergy/GetList?database=" + db + "&tablename=" + tbl + "&page=" + pg + "&rows=" + rws,
        contentType: 'application/json',
        data: jobj,
        dataType: "json",
        async: false,
        type: "POST",
        success: OnSuccessgetlist,
        /*Create a Function to run the Success Action */
        error: errorAction
    });
}

/*==Get the selected Record from the Table==*/
function callgetrow(db, tbl, pk, jobj) {
    $.ajax({
        beforeSend: function(xhr) {
            xhr.setRequestHeader("Authorization", "Bearer " + at);
        },
        url: "http://www.cgvakstage.com:5500/api/newsynergy/GetRow?database=" + db + "&tablename=" + tbl + "&pk=" + pk,
        contentType: 'application/json',
        data: jobj,
        dataType: "json",
        async: false,
        type: "POST",
        success: OnSuccessgetrow,
        /*Create a Function to run the Success Action */
        error: errorAction
    });
}

/*==Insert Record==*/
function callinsert(db, tbl, pk, jobj) {
    $.ajax({
        beforeSend: function(xhr) {
            xhr.setRequestHeader("Authorization", "Bearer " + at);
        },
        url: "http://www.cgvakstage.com:5500/api/newsynergy/Insert?database=" + db + "&tablename=" + tbl + "&pk=" + pk,
        contentType: 'application/json',
        data: jobj,
        dataType: "json",
        async: false,
        type: "POST",
        success: OnSuccessInsert,
        /*Create a Function to run the Success Action */
        error: errorAction
    });
}

/*==Update Record==*/
function callupdate(db, tbl, jobj) {
    $.ajax({
        beforeSend: function(xhr) {
            xhr.setRequestHeader("Authorization", "Bearer " + at);
        },
        url: "http://www.cgvakstage.com:5500/api/newsynergy/Update?database=" + db + "&tablename=" + tbl,
        contentType: 'application/json',
        data: jobj,
        dataType: "json",
        async: false,
        type: "POST",
        success: OnSuccessUpdate,
        /*Create a Function to run the Success Action */
        error: errorAction
    });
}

/*==Delete Record==*/
function calldelete(db, tbl, jobj) {
    $.ajax({
        beforeSend: function(xhr) {
            xhr.setRequestHeader("Authorization", "Bearer " + at);
        },
        url: "http://www.cgvakstage.com:5500/api/newsynergy/Delete?database=" + db + "&tablename=" + tbl,
        contentType: 'application/json',
        data: jobj,
        dataType: "json",
        async: false,
        type: "POST",
        success: OnSuccessDelete,
        /*Create a Function to run the Success Action */
        error: errorAction
    });
}
/*==Get the Columns Details of a Table==*/
function callgettablecolumns(db, tbl) {
    $.ajax({
        beforeSend: function(xhr) {
            xhr.setRequestHeader("Authorization", "Bearer " + at);
        },
        url: "http://www.cgvakstage.com:5500/api/newsynergy/GetTableColumns?database=" + db + "&tablename=" + tbl,
        dataType: "json",
        async: false,
        type: "GET",
        success: OnSuccessTableColumns,
        /*Create a Function to run the Success Action */
        error: errorAction
    });
}

/*==Authentication using UserName and Password==*/
function getAuthentication(un, pw) {
    $.ajax({
        url: "http://www.cgvakstage.com:5050/api/token/auth?grant_type=password&client_id=" + ci + "&client_secret=" + cs + "&username=" + un + "&password=" + pw,
        dataType: "json",
        async: false,
        type: "GET",
        success: function(result) {
            dat = JSON.parse(result.data);
            at = dat.access_token;
            rt = dat.refresh_token;
            return true;
            //$("#result").html("Code : " + result.code + "<br/>Message : " + result.message + "<br/>Data:<br/>Access_Token:" + at + "<br/>Refresh Token:" + rt + "<br/>Expires In:" + dat.expires_in);
        },
        error: errorAction,
        afterSend: function() {
            $('.datatable-ajax-source table').dataTable().reload();
        }
    });
}

/*==Get Access Token using Valid Refresh Token==*/
function getAccessToken() {
    $.ajax({
        url: "http://www.cgvakstage.com:5050/api/token/auth?grant_type=refresh_token&client_id=" + ci + "&refresh_token=" + rt,
        dataType: "json",
        async: false,
        type: "GET",
        success: function(result) {
            dat = JSON.parse(result.data);
            at = dat.access_token;
            rt = dat.refresh_token;
            //$("#result").html("Code : " + result.code + "<br/>Message : " + result.message + "<br/>Data:<br/>Access_Token:" + at + "<br/>Refresh Token:" + rt + "<br/>Expires In:" + dat.expires_in);
            return true;
        },
        error: errorAction
    });
}

function errorAction(xhr) {
    console.log("An error occured: " + xhr.status + " " + xhr.statusText);
    if (xhr.status == 401 && nTimes < 5)
        getAccessToken();
    return false;
}


function callgetRowCount(db,tbl,jsonObj){
	
    $.ajax({
        beforeSend: function(xhr) {
            xhr.setRequestHeader("Authorization", "Bearer " + at);
        },
        url: "http://www.cgvakstage.com:5500/api/newsynergy/FindDataCount?database=" + db + "&tablename=" + tbl,
        contentType: 'application/json',
        data: jsonObj,
        dataType: "json",
        async: false,
        type: "POST",
        success: onSuccessRowCount,
        /*Create a Function to run the Success Action */
        error: errorAction
    });
	
}